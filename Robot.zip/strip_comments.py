import re

def remove_comments_cpp(text):
    # Remove // comments
    text = re.sub(r'//.*', '', text)
    # Remove /* */ comments (multiline)
    text = re.sub(r'/\*[\s\S]*?\*/', '', text)
    return text

def remove_comments_python(text):
    # Remove # comments
    text = re.sub(r'#.*', '', text)
    return text

def process_codebase(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    # Regex to find headers and capture the path
    # Using multiline string for regex to avoid syntax errors with newlines
    pattern = re.compile(r'''={10,}
FILE PATH: (.*?)
={10,}
''', re.DOTALL | re.MULTILINE)
    
    parts = pattern.split(content)
    
    cleaned_full_text = ""
    total_loc = 0
    
    start_index = 1 if len(parts) > 1 else 0
    
    for i in range(start_index, len(parts), 2):
        file_path = parts[i].strip()
        file_content = parts[i+1]
        
        is_python = file_path.endswith('.py')
        
        if is_python:
            clean_content = remove_comments_python(file_content)
        else:
            clean_content = remove_comments_cpp(file_content)
            
        lines = clean_content.splitlines()
        non_empty_lines = [line.rstrip() for line in lines if line.strip()]
        
        if non_empty_lines:
            cleaned_chunk = "\n".join(non_empty_lines)
            cleaned_full_text += f"FILE: {file_path}\n"
            cleaned_full_text += cleaned_chunk + "\n"
            total_loc += len(non_empty_lines)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(cleaned_full_text)
        
    print(f"Total Lines of Code (LOC): {total_loc}")

if __name__ == "__main__":
    process_codebase('full_codebase.txt', 'clean_code.txt')
